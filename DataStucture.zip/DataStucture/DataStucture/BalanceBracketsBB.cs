﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class BalanceBracketsBB
    {
        public static bool BBWS(char[] exp)
        {
            int len;
            //char s;
            Stack_Array<char> objbrackets = new Stack_Array<char>(exp.Length);
            for (int i = 0; i < exp.Length; i++)
            {
                switch (exp[i])
                {
                    case '[':
                    case '{':
                    case '(':
                    case '<':
                        objbrackets.push(exp[i]); break;
                    case ']':
                        len = Array.IndexOf(objbrackets.array, ']');
                        if (objbrackets.array[objbrackets.pop()] == '[') objbrackets.push(exp[i]);
                        else objbrackets.push(exp[len + 1]);
                        break;
                    case '}':
                        len = Array.IndexOf(objbrackets.array, '}');
                        if (objbrackets.array[objbrackets.pop()] == '{') objbrackets.push(exp[i]);
                        else objbrackets.push(exp[len + 1]);
                        break;
                    case ')':
                        len = Array.IndexOf(objbrackets.array, ')');
                        if (objbrackets.array[objbrackets.pop()] == '(') objbrackets.push(exp[i]);
                        else objbrackets.push(exp[len + 1]);
                        break;
                    case '>':
                        len = Array.IndexOf(objbrackets.array, '<');
                     //   s = exp[len + 1];
                        if (objbrackets.array[objbrackets.pop()] == '<') objbrackets.push(exp[i]); 
                        else objbrackets.push(exp[len+1]);
                        break;
                }
            }
            foreach(char c in objbrackets.array)
            Console.Write(c);

            return objbrackets.isempty();
        }
    }
}
