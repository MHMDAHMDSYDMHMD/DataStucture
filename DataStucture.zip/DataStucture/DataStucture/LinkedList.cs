﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class LinkedList<T>
    {
        public int count;
        Node<T> head;
        Node<T> tail;
        public LinkedList()
        {
            head = tail = null;
        }
        public void addnewlist(T Value)
        {
            Node<T> item = new Node<T>(Value);
            if (head == null)
            {
                head = item;
                tail = item;
            }
            else
            {
                tail.Next = item;
                tail = item;
            }
            count++;
        }
        public void dispalydata()
        {
            Node<T> start = head;
            if (start == null)
            {
                Console.WriteLine("LinkedList is Empty");
            }
            else
            {
                while (tail != null && start != null)
                {
                    Console.WriteLine(start.Data);
                    start = start.Next;
                }
                Console.WriteLine("count is : " + count);
            }
        }
           public void insertnodeinfirstlist(T Value)
        {
            Node<T> itemfirst = new Node<T>(Value);
            if(head == null)
            {
                head = itemfirst;
                tail = itemfirst;
            }
            else
            {
                itemfirst.Next = head;
                head = itemfirst;
            }
            count++;
        }
        public void searchinlinkedlist(T Value )
        {
            int pos;
                pos = 0;
            bool test = false;
            T boxvalue = Value;
            
            Node<T> current = new Node<T>(Value);
                if(current.Data.Equals(Value))
                {
                    Console.WriteLine($"Item {Value} Found Position {pos} .");
                    test = true;
                return;
                }
                current = current.Next;
            ++pos;

            if (current == null)
            {
                Console.WriteLine(" This Item Not Found !");
                test = false;
            }
            if (test) { 
            searchinlinkedlist(boxvalue);
            }
        }
        public void deletoneelementfromlinkedlist(T Value)
        {
            if(head == null)
            {
                Console.WriteLine("linkedlist is empty");
                count = 0;
                return;
            }
            if(head.Data.Equals(Value))
            {
                head = head.Next;
            }
            Node<T> previos = head;
            Node<T> current = head.Next;
           
                while(current != null)
                {
                if (current.Data.Equals(Value))
                    {
                        previos.Next = current.Next;
                    }
                current = current.Next;
                previos = previos.Next;
                /* 
                 * < 
                 * if (previos.Next == null) 
                 * tail = previos; >> previos = previos.Next; 
                 *  >
                   //if (previos.Next == null) tail = previos;
                 */
            }

            if (current == null)
            {
                Console.WriteLine("empty");
            }
            count--;

        }

        public void addatsecificloation(T Value , int previos)
        {

            Node<T> current = head;
            Node<T> nodeabycl = new Node<T>(Value);
            //for(int i = 0; i < Convert.ToInt32(previos) ; i++)
            //{
            //    current = current.Next;
            if (count < previos)
            {
                Console.WriteLine("Out Of Range");
                return;
            }
            //    }
            //}
            if(previos <= 0)
            {
                nodeabycl.Next = head;
                head = nodeabycl;
                count++;
                return;
            }
            int i = 0;
            while (i < --previos) { 
                current = current.Next;
                i++;
            }
            nodeabycl.Next = current.Next;
            current.Next = nodeabycl;
            count++;
        }



    }
    }
    

