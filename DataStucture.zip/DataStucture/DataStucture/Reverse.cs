﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class Reverse
    {
       public static string reverse(string name)
        {
            string rename = "";
            Stack_Array<char> reverseobj = new Stack_Array<char>(name.Length);
            foreach (var x in name)
            {
                reverseobj.push(x);
            }
            while (!reverseobj.isempty())
            {
                // Console.WriteLine(reverseobj.array[reverseobj.pop()]);
                rename += reverseobj.array[reverseobj.pop()];
            }
            return rename;
        }
    }
}
