﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class Queue_Array<t>
    {
        public int front;
        public int peek;
        public t[] queuearray;
        public int count;
       public Queue_Array(int size)
        {
            queuearray = new t[size];
            front = count = peek = 0;
        }
        public void enqueue(t value)
        {
            if (count==queuearray.Length)
            {
                Console.WriteLine("queue is complited!");return;
            }
            queuearray[peek] = value; count++; peek++;
        }
        public void enqueue()
        {
            t value ;
            if (count ==0)
            {
                Console.WriteLine("queue is empty!"); return;
            }
            value = queuearray[front] ; count--; front++;
        }
    }
}
