﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using DataStucture;
namespace DataStucture
{
    class Program
    {
        static void Main(string[] args)
        {

            #region Initializations
            //static  Func<bool> nm()
            //  {
            //      Func<bool> vb = nm();
            //      return vb;
            //  }
            // LinkedList<int> nodeone = new LinkedList<int>();
            // nodeone.addnewlist(1);
            // nodeone.addnewlist(2);
            // nodeone.addnewlist(3);
            // nodeone.addnewlist(4);
            // nodeone.insertnodeinfirstlist(5);
            // nodeone.dispalydata();
            // Console.WriteLine("**** __searchinlinkedlist__");
            // nodeone.searchinlinkedlist(3);
            // Console.WriteLine("**** __deletoneelementfromlinkedlist__");
            // nodeone.deletoneelementfromlinkedlist(2);
            // nodeone.dispalydata();
            // Console.WriteLine("**** __addatsecificloation__");
            // nodeone.addatsecificloation(7, 0);
            // nodeone.dispalydata();
            // Console.WriteLine("************************");
            // Console.WriteLine("*______________________*");
            // Console.WriteLine("*(^_^) stack code (^_^)*");
            // Console.WriteLine("*______________________*");
            // Console.WriteLine("************************");
            // Stack_Array<int> arrstack = new Stack_Array<int>(5);
            // Console.WriteLine(arrstack.top);
            // arrstack.push(1);           
            // arrstack.push(2);           
            // arrstack.push(4);           
            // arrstack.push(5);           
            // arrstack.push(6);
            //// arrstack.push(5);
            // Console.WriteLine(arrstack.top);
            // var num0 = arrstack.pop();
            // var num1 = arrstack.pop();
            // Console.WriteLine(arrstack.array[num1]);
            // Console.WriteLine(arrstack.isempty());
            // Console.WriteLine(arrstack.peek());
            // Console.WriteLine();
            // Console.WriteLine(" reverse string");
            // Console.WriteLine();
            // Console.Write("enter sting to reverse it : ");
            // string input = Console.ReadLine();
            // var str = Reverse.reverse(input);
            // Console.WriteLine(str);

            // Console.Write("enter the string : ");
            // string vv = Console.ReadLine();
            // Console.WriteLine(BalanceBracketsBB.BBWS(vv.ToCharArray()));

            //Console.Write("enter the infix : ");
            //string inf = Console.ReadLine();
            //Console.WriteLine(infixVSpostfix.infixtopostfix(inf));

            //Queue<int> o = new Queue<int>();
            //o.Enqueue(9);
            //o.Enqueue(3);
            //Console.WriteLine(o.Count());
            //Console.WriteLine(o.First());
            //Console.WriteLine(o.ToList().ForEach((x) => Console.WriteLine(x));

            Binary_Node b = new Binary_Node(0);
            for (int i = 1; i <= 9; i++)b.add(i); 
            Console.WriteLine(b.head.leftnode.value);

            #endregion

            // < to show resualt without end run > "don't remove this line & then this"
            StopWholeRun.StopWholeRunMethod();
        }
     
    }
}
