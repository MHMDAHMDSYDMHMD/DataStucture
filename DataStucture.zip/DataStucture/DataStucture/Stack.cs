﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class Stack_Array<S>
    {
        public S[] array;
        public int top;
        public Stack_Array(int size)
        {
            array = new S[Convert.ToInt32(size)];
            top = -1;
        }
        public void push(S Value)
        {
            if(top == (array.Length-1))
            {
                Console.WriteLine("can't add anther item \n stackarray is complated");
                return;
            }
            else
            {
                top++;
                array[top] = Value;
            }
        }
        public int pop()
        {
            int t = top;
            if (top < 0) Console.WriteLine("stackunderflow");
            else top--;
            return t;
        }
        public bool isempty()
        {
            if(top < 0)return true;
            return false;
        }
        public int peek()
        {
            if (isempty())Console.WriteLine(" stack under flow");
            return top;            
        }
    }
}
