﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class infixVSpostfix
    {
        public static string infixtopostfix(string infix)
        {
            string postfix = "";
            int precedence;
            Stack_Array<char> objs = new Stack_Array<char>(infix.Length);
            for (int i = 0; i < infix.Length; i++)
            {
                char ch = infix[i];
                if (ch == '+' || ch == '*' || ch == '/' || ch == '-')
                {
                    if (objs.isempty())
                        objs.push(ch);
                    else
                    {
                        precedence = proirty(ch);
                        if (precedence == 1) { objs.push(ch); postfix += objs.array[objs.top]; }
                        else if (precedence == 2) { objs.push(ch); postfix += objs.array[objs.top]; }
                        else objs.push(ch);
                    }
                }
                else if (ch >= 0x01 && ch <= 0x39) objs.push(ch);
                else continue;
            }
            foreach (var item in objs.array)
            {
                Console.Write(item);
            }
            return postfix;
        }
        public static int proirty(char ch)
        {
            int pre =0;
            if (ch == '*' || ch == '/') pre = 1;
            if(ch == '+' || ch == '-') pre = 2;
            return pre;
        }
    }
}
