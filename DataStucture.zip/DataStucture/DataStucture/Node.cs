﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
        public  class Node<T>
        {
       
            Node<T> next;

            public Node()
            {
            }
            public Node (T Value)
                {
                this.data = Value;
                Next = null;

                }

         

            private T data;

            public T Data
            {
                get { return data; }
                set { data = value; }
            }
            public Node<T> Next
            {
                get { return next; }
                set { next = value; }
            }
            
        } 
        
    }

