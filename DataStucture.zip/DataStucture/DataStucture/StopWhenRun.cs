﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
  public  class StopWholeRun
    {
        public static bool StopWholeRunMethod()
        {
            Console.WriteLine();
            Console.WriteLine("  _______________________________________________");
            Console.WriteLine("  Enter Any Key to Exit From Program >>>...");
            Console.ReadKey();
            return true;
        }
    }
}
