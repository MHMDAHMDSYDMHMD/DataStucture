﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataStucture
{
    class Binary_Node
    {
        public int value;
        public int count;
        public Binary_Node rightnode;
        public Binary_Node head;
        public Binary_Node leftnode;
        public Binary_Node(int x)
        {
            value = x;
        }
        public void add(int value)
        {
            if (head == null) head = new Binary_Node(value);
            else addto(head, value);
        }
        public void addto(Binary_Node node,int value)
        {
            if (node.leftnode == null) { node.leftnode = new Binary_Node(value); return; }
            else { node.rightnode = new Binary_Node(value); return; }
        }
        private void preorder(Binary_Node node)
        {
            if (node != null)
            {
                Console.WriteLine(node.value);
                preorder(node.leftnode);
                preorder(node.rightnode);
            }
        }
        public void preorder()
        {
            preorder(head);
        }
        private void inorder(Binary_Node node)
        {
            if (node != null)
            {
                preorder(node.leftnode);
                Console.WriteLine(node.value);
                preorder(node.rightnode);

            }
        }
        public void inorder()
        {
            inorder(head);
        }
        private void postorder(Binary_Node node)
        {
            if (node != null)
            {
                postorder(node.leftnode);
                postorder(node.rightnode);
                Console.WriteLine(node.value);
            }
        }
        public void postorder()
        {
            postorder(head);
        }
    }

}
